# CSES Computer Vision Workshop 3
